document.addEventListener('DOMContentLoaded', function() {
    let tasks = [];
  
    const todoForm = document.getElementById('todo-form');
    const todoInput = document.getElementById('todo-input');
    const todoList = document.getElementById('todo-list');
    const btnFilterCompleted = document.getElementById('filter-completed');
    const btnFilterIncomplete = document.getElementById('filter-incomplete');
    const btnSortNewest = document.getElementById('sort-newest');
    const btnSortOldest = document.getElementById('sort-oldest');
  
    const postsContainer = document.getElementById('posts-container');
    const loadPostsBtn = document.getElementById('load-posts-btn');
    const addPostForm = document.getElementById('add-post-form');
    const postMessage = document.getElementById('post-message');
  
    function loadTasks() {
      const storedTasks = localStorage.getItem('tasks');
      if (storedTasks) {
        tasks = JSON.parse(storedTasks);
      }
    }
  
    function saveTasks() {
      localStorage.setItem('tasks', JSON.stringify(tasks));
    }
  
    function renderTasks(displayTasks = tasks) {
      todoList.innerHTML = '';
      displayTasks.map(task => {
        const li = document.createElement('li');
        li.className = 'todo-item';
        li.setAttribute('data-id', task.id);
  
        const taskText = document.createElement('span');
        taskText.textContent = task.text;
        if (task.completed) {
          taskText.classList.add('completed');
        }
  
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = task.completed;
        checkbox.addEventListener('change', function() {
          toggleComplete(task.id);
        });
  
        const delButton = document.createElement('button');
        delButton.textContent = 'Delete';
        delButton.className = 'delete-btn';
        delButton.addEventListener('click', function() {
          deleteTask(task.id);
        });
  
        li.appendChild(checkbox);
        li.appendChild(taskText);
        li.appendChild(delButton);
        todoList.appendChild(li);
      });
    }
  
    function addTask(taskText) {
      const task = {
        id: Date.now(),
        text: taskText,
        dateCreated: new Date(),
        completed: false
      };
      tasks.push(task);
      saveTasks();
      renderTasks();
    }
  
    function deleteTask(id) {
      tasks = tasks.filter(task => task.id !== id);
      saveTasks();
      renderTasks();
    }
  
    function toggleComplete(id) {
      tasks = tasks.map(task => {
        if (task.id === id) {
          return { ...task, completed: !task.completed };
        }
        return task;
      });
      saveTasks();
      renderTasks();
    }
  
    function filterTasks(completedStatus) {
      const filtered = tasks.filter(task => task.completed === completedStatus);
      renderTasks(filtered);
    }
  
    function sortTasks(order = 'newest') {
      const sorted = [...tasks];
      sorted.sort((a, b) => {
        if (order === 'newest') {
          return new Date(b.dateCreated) - new Date(a.dateCreated);
        } else {
          return new Date(a.dateCreated) - new Date(b.dateCreated);
        }
      });
      renderTasks(sorted);
    }
  
    
    todoForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const text = todoInput.value.trim();
      if (text !== '') {
        addTask(text);
        todoInput.value = '';
      }
    });
  
    btnFilterCompleted.addEventListener('click', function() {
      filterTasks(true);
    });
  
    btnFilterIncomplete.addEventListener('click', function() {
      filterTasks(false);
    });
  
    btnSortNewest.addEventListener('click', function() {
      sortTasks('newest');
    });
  
    btnSortOldest.addEventListener('click', function() {
      sortTasks('oldest');
    });
  
    loadTasks();
    renderTasks();
  
    
    loadPostsBtn.addEventListener('click', async () => {
      postsContainer.innerHTML = '<p class="loading">Loading data...</p>';
      try {
        const response = await fetch("http://localhost:5000/api/posts"
      );
        const posts = await response.json();
  
        if (posts.length === 0) {
          postsContainer.innerHTML = '<p>No results found.</p>';
          return;
        }
  
        postsContainer.innerHTML = '';
        posts.slice(0, 5).forEach(post => {
          const postCard = document.createElement('div');
          postCard.className = 'post-card';
          postCard.innerHTML = `
            <h3>${post.title}</h3>
            <button class="details-btn" data-id="${post.id}">See Details</button>
            <p class="post-details" id="details-${post.id}" style="display:none;">${post.body}</p>
          `;
          postsContainer.appendChild(postCard);
        });
  
        document.querySelectorAll('.details-btn').forEach(btn => {
          btn.addEventListener('click', (e) => {
            const id = e.target.getAttribute('data-id');
            const details = document.getElementById(`details-${id}`);
            details.style.display = details.style.display === 'none' ? 'block' : 'none';
          });
        });
  
      } catch (error) {
        postsContainer.innerHTML = '<p class="error">Failed to load posts. Please try again later.</p>';
      }
    });
  
    
    addPostForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const title = document.getElementById('post-title').value.trim();
      const body = document.getElementById('post-body').value.trim();
  
      if (title && body) {
        try {
          const response = await fetch("http://localhost:5000/api/posts"
          , {
            method: 'POST',
            body: JSON.stringify({
              title: title,
              body: body,
              userId: 1
            }),
            headers: {
              'Content-type': 'application/json; charset=UTF-8',
            },
          });
  
          const result = await response.json();
          console.log('New Post Added:', result);
          postMessage.textContent = 'New post successfully added!';
          postMessage.className = 'success';
          addPostForm.reset();
  
        } catch (error) {
          postMessage.textContent = 'Failed to add post. Try again!';
          postMessage.className = 'error';
        }
      }
    });
  
  });
  

document.getElementById("load-posts").addEventListener("click", async () => {
  const container = document.getElementById("posts-container");
  container.innerHTML = "<p class='loading'>Loading data...</p>";
  try {
    const res = await fetch("http://localhost:5000/api/posts");
    const posts = await res.json();
    if (!posts.length) {
      container.innerHTML = "<p>No results found.</p>";
      return;
    }
    container.innerHTML = "";
    posts.slice(0, 5).forEach(post => {
      const div = document.createElement("div");
      div.className = "card";
      div.innerHTML = `
        <h3>${post.title}</h3>
        <button onclick="toggleDetails('post-${post.id}')">See Details</button>
        <p id="post-${post.id}" style="display:none">${post.body}</p>
      `;
      container.appendChild(div);
    });
  } catch (err) {
    container.innerHTML = "<p class='error'>Failed to load posts. Try again later.</p>";
  }
});

function toggleDetails(id) {
  const el = document.getElementById(id);
  el.style.display = el.style.display === "none" ? "block" : "none";
}

document.getElementById("post-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const title = document.getElementById("post-title").value;
  const body = document.getElementById("post-body").value;
  const msg = document.getElementById("post-message");
  try {
    const res = await fetch("http://localhost:5000/api/posts", {
      method: "POST",
      body: JSON.stringify({ title, body, userId: 1 }),
      headers: { "Content-type": "application/json" }
    });
    const result = await res.json();
    console.log("Posted:", result);
    msg.textContent = "New post successfully submitted!";
    msg.className = "success";
    document.getElementById("post-form").reset();
  } catch {
    msg.textContent = "Failed to submit post.";
    msg.className = "error";
  }
});
