
# Final Project 4: Personal Dashboard Web Application

## 📌 Overview

This is a personal dashboard web application designed with HTML, CSS, JavaScript, and a Node.js backend using Express. It includes a login form, an interactive to-do list, and a section that interacts with external data through a simulated API.

---

## 🌟 Key Features

### 🔐 Login Page (`dashlogin.html`)
- Simple form-based login screen that accepts Name, Email, and Password.
- Styled input validation interface.

### 📋 Dashboard (`index.html`)
- Central page of the app with three core sections:
  - **To-Do List**: Add, filter, and sort tasks with local storage persistence.
  - **External Posts**: Button fetches simulated API posts.
  - **New Post Form**: Users can submit new posts via the backend.

### ✅ To-Do List (`indexv1.html`)
- Dedicated page for managing tasks with completion tracking.
- Filtering and sorting by status or creation time.

### 🎨 Styling (`p2New_updated.css`)
- Custom CSS provides responsive layout, clear navigation, and modern UI elements for all components.

### ⚙️ Functionality (`p3New_updated.js`)
- Handles:
  - Task creation, filtering, sorting, and deletion.
  - API calls to load and submit posts.
  - Toggle visibility of post details.

### 🖥️ Backend (`server.js`)
- Node.js server using Express.js and CORS.
- API Endpoints:
  - `GET /api/posts`: Returns a list of demo posts.
  - `POST /api/posts`: Accepts and logs new posts.

---

## 🛠️ Requirements

- Node.js and npm installed
- Run the backend server:
  ```bash
  node server.js
  ```
- Open `index.html` in a browser to view the dashboard.

---

## 📂 File Structure

```
Final_project4/
│
├── dashlogin.html        # Login page
├── index.html            # Main dashboard
├── indexv1.html          # To-do list focused version
├── p2New_updated.css     # Styling
├── p3New_updated.js      # JavaScript logic
├── server.js             # Express backend
└── README.md             # Project documentation
```

---

## 📬 Notes

